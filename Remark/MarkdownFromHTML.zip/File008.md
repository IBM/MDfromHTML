 Open/Close Main menu

 *  [Go to W3 site (external link)][Go to W3 site _external link]
 *   Help@**IBM**Help@IBM

Search input  Search  Clear

Cancel

Top results

Press Enter to see all  search results

Welcome, Sign In 

 *  
 *   Search
 *   Search
 *  Settings
    
    English  
    Change language
    
     *   Français (Canadien) 
     *   日本語 
    
    ![Image 1][]
    
    United States of America (USA)  
    Change location
    
    Filter by location name×
    
     *  ![Image 1][] Afghanistan
     *  ![Image 1][] Albania
     *  ![Image 1][] Algeria
     *  ![Image 1][] Angola
     *  ![Image 1][] Antigua and Barbuda
     *  ![Image 1][] Argentina
     *  ![Image 1][] Armenia
     *  ![Image 1][] Aruba
     *  ![Image 1][] Australia
     *  ![Image 1][] Austria
     *  ![Image 1][] Azerbaijan
     *  ![Image 1][] Bahamas
     *  ![Image 1][] Bahrain
     *  ![Image 1][] Bangladesh
     *  ![Image 1][] Barbados
     *  ![Image 1][] Belarus
     *  ![Image 1][] Belgium
     *  ![Image 1][] Benin
     *  ![Image 1][] Bermuda
     *  ![Image 1][] Bolivia, Plurinational State of
     *  ![Image 1][] Bosnia and Herzegovina
     *  ![Image 1][] Botswana
     *  ![Image 1][] Brazil (BR)
     *  ![Image 1][] Brunei Darussalam
     *  ![Image 1][] Bulgaria
     *  ![Image 1][] Burkina Faso
     *  ![Image 1][] Burundi
     *  ![Image 1][] Cambodia
     *  ![Image 1][] Cameroon
     *  ![Image 1][] Canada
     *  ![Image 1][] Cape Verde
     *  ![Image 1][] Cayman Islands
     *  ![Image 1][] Central African Republic
     *  ![Image 1][] Chad
     *  ![Image 1][] Chile
     *  ![Image 1][] Colombia
     *  ![Image 1][] Costa Rica
     *  ![Image 1][] Cote d'Ivoire
     *  ![Image 1][] Croatia
     *  ![Image 1][] Cuba
     *  ![Image 1][] Cyprus
     *  ![Image 1][] Czech Republic
     *  ![Image 1][] Denmark
     *  ![Image 1][] Djibouti
     *  ![Image 1][] Dominican Republic
     *  ![Image 1][] Ecuador
     *  ![Image 1][] Egypt
     *  ![Image 1][] El Salvador
     *  ![Image 1][] Equatorial Guinea
     *  ![Image 1][] Eritrea
     *  ![Image 1][] Estonia
     *  ![Image 1][] Ethiopia
     *  ![Image 1][] Faroe Islands
     *  ![Image 1][] Finland
     *  ![Image 1][] France
     *  ![Image 1][] French Guiana
     *  ![Image 1][] French Polynesia
     *  ![Image 1][] Gabon
     *  ![Image 1][] Gambia
     *  ![Image 1][] Georgia
     *  ![Image 1][] Germany
     *  ![Image 1][] Ghana
     *  ![Image 1][] Greece
     *  ![Image 1][] Greenland
     *  ![Image 1][] Guadeloupe
     *  ![Image 1][] Guam
     *  ![Image 1][] Guatemala
     *  ![Image 1][] Guinea
     *  ![Image 1][] Guinea-Bissau
     *  ![Image 1][] Guyana
     *  ![Image 1][] Haiti
     *  ![Image 1][] Honduras
     *  ![Image 1][] Hong Kong
     *  ![Image 1][] Hungary
     *  ![Image 1][] Iceland
     *  ![Image 1][] India
     *  ![Image 1][] India-South Asia IMT
     *  ![Image 1][] Indonesia
     *  ![Image 1][] Iran, Islamic Republic of
     *  ![Image 1][] Iraq
     *  ![Image 1][] Ireland
     *  ![Image 1][] Israel
     *  ![Image 1][] Italy
     *  ![Image 1][] Jamaica
     *  ![Image 1][] Japan
     *  ![Image 1][] Jordan
     *  ![Image 1][] Kazakhstan
     *  ![Image 1][] Kenya
     *  ![Image 1][] Korea, Republic of
     *  ![Image 1][] Kuwait
     *  ![Image 1][] Kyrgyzstan
     *  ![Image 1][] Lao People's Democratic Republic
     *  ![Image 1][] Latvia
     *  ![Image 1][] Lebanon
     *  ![Image 1][] Lesotho
     *  ![Image 1][] Liberia
     *  ![Image 1][] Libya
     *  ![Image 1][] Lithuania
     *  ![Image 1][] Luxembourg
     *  ![Image 1][] Macao
     *  ![Image 1][] Macedonia, The former Yugoslav Republic of
     *  ![Image 1][] Madagascar
     *  ![Image 1][] Malawi
     *  ![Image 1][] Malaysia
     *  ![Image 1][] Mali
     *  ![Image 1][] Malta
     *  ![Image 1][] Mauritania
     *  ![Image 1][] Mauritius
     *  ![Image 1][] Mexico (MX)
     *  ![Image 1][] Moldova, Republic of
     *  ![Image 1][] Morocco
     *  ![Image 1][] Mozambique
     *  ![Image 1][] Namibia
     *  ![Image 1][] Nepal
     *  ![Image 1][] Netherlands
     *  ![Image 1][] New Caledonia
     *  ![Image 1][] New Zealand
     *  ![Image 1][] Nicaragua
     *  ![Image 1][] Niger
     *  ![Image 1][] Nigeria
     *  ![Image 1][] Norway
     *  ![Image 1][] Oman
     *  ![Image 1][] Pakistan
     *  ![Image 1][] Panama
     *  ![Image 1][] Paraguay
     *  ![Image 1][] Peru
     *  ![Image 1][] Philippines
     *  ![Image 1][] Poland
     *  ![Image 1][] Portugal
     *  ![Image 1][] Puerto Rico
     *  ![Image 1][] Qatar
     *  ![Image 1][] Romania
     *  ![Image 1][] Russian Federation
     *  ![Image 1][] Rwanda
     *  ![Image 1][] Saint Lucia
     *  ![Image 1][] Sao Tome and Principe
     *  ![Image 1][] Saudi Arabia
     *  ![Image 1][] Senegal
     *  ![Image 1][] Serbia
     *  ![Image 1][] Sierra Leone
     *  ![Image 1][] Singapore
     *  ![Image 1][] Slovakia
     *  ![Image 1][] Slovenia
     *  ![Image 1][] Somalia
     *  ![Image 1][] South Africa (ZA)
     *  ![Image 1][] Spain
     *  ![Image 1][] Sri Lanka
     *  ![Image 1][] Sudan
     *  ![Image 1][] Suriname
     *  ![Image 1][] Svalbard and Jan Mayen
     *  ![Image 1][] Swaziland
     *  ![Image 1][] Sweden
     *  ![Image 1][] Switzerland
     *  ![Image 1][] Taiwan
     *  ![Image 1][] Tajikistan
     *  ![Image 1][] Tanzania, United Republic of
     *  ![Image 1][] Thailand
     *  ![Image 1][] The Peoples Rep of China
     *  ![Image 1][] Trinidad and Tobago
     *  ![Image 1][] Tunisia
     *  ![Image 1][] Turkey (TR)
     *  ![Image 1][] Turkmenistan
     *  ![Image 1][] Uganda
     *  ![Image 1][] Ukraine
     *  ![Image 1][] United Arab Emirates (UAE)
     *  ![Image 1][] United Kingdom (UK)
     *  ![Image 1][] Uruguay
     *  ![Image 1][] Uzbekistan
     *  ![Image 1][] Venezuela, Bolivarian Republic of
     *  ![Image 1][] Viet Nam
     *  ![Image 1][] Virgin Islands, U.S.
     *  ![Image 1][] Yemen
     *  ![Image 1][] Zambia
     *  ![Image 1][] Zimbabwe
    
    Default![Image 1][] Change theme
    
     *  Contrast![Image 1][]
     *  Low-light![Image 1][]
 *  ![Image 1][] Showing content for United States of America (USA). Change country

 *    Home
 *    Top Issues
 *    Products
 *    All Outages
 *    My Tickets
 *  [  My Devices][My Devices]
 *  
 *    Settings

 w3

Search input

[yourIBM][Go to W3 site _external link]

 You must enable Javascript for Help@IBM to work properly.

![platform][Image 1] Mac  Currently selected platform

###  ###

### Your Platform ###

Your current platform is Mac. You can change it here any time.

Got it!

![platform][Image 1] Mac Currently selected platform

###  ###

### Your Platform ###

Your current platform is Mac. You can change it here any time.

Got it!

Products

 *    Home
 *    Top Issues
 *    Productsactive
 *    All Outages
 *    My Tickets
 *  [  My Devices][My Devices]

 *  ![platform][Image 1] Windows 7
 *  ![platform][Image 1] Windows 10
 *  ![platform][Image 1] Linux
 *  ![platform][Image 1] iOS
 *  ![platform][Image 1] Android

 *  Contact Support

Select Platform

 *  ![platform][Image 1]
    
    Windows 7
 *  ![platform][Image 1]
    
    Windows 10
 *  ![platform][Image 1]
    
    Linux
 *  ![platform][Image 1]
    
    iOS
 *  ![platform][Image 1]
    
    Android
 *  ![platform][Image 1]
    
    MacCurrently selected platform

 *  Collaboration & Social
 *  W3 Connections

# Use w3 Connections #

Actions

[View as PDF][]

Copied to clipboard

Input with selected link to share Links to share

 *  https://w3.ibm.com/help/\#/article/use\_w3connectionsWithout personalization
 *  https://w3.ibm.com/help/\#/mac/us\_imt/en/article/use\_w3connections With personalization (Mac, English, )

Copy

Overview  Toggle visibility of the chapters menu.

 *  Overview
 *  Different Instances: w3 and Cloud
 *  Engage and Connect Using Profiles
 *  Collaborate Flexibly Using Communities
 *  Share and Co-Create Content Using Files
 *  Curate Knowledge Using Wikis and Bookmarks
 *  Content Retention and Restore
 *  Ex-Employees' Profiles and Content
 *  Security and Data Protection

## Overview ##

Get work done in new and better ways by using [w3 Connections][], IBM's enterprise social business platform.

**Note**: w3 Connections has many names including Connections, IBM Connections, "IBM Connections on w3," w3-Connections, and a few other variations of the same names.

Use w3 Connections to:

 *  **Engage with IBM colleagues**: Network, engage, and collaborate with colleagues to locate expertise fast and get work done better.
 *  **Collaborate with purpose**: Collaborate on a shared purpose to bridge social and traditional ways of working using **Communities**.
 *  **Unlock and co-create knowledge**: Speed up your business processes by sharing and co-creating content using **files** and **wikis**. Use **Forums**, Profile Status Updates, and Community Status Updates to ask and answer questions.
 *  **Serve clients better using Search**: Use the knowledge shared by IBMers on w3 Connections to solve client problems faster and better by **Searching IBM Connections** and **Advanced searching**.
 *  **Manage projects and programs effectively**: Structure your work, enable project members to own their updates, and stay informed on project status, by using **Activities**.
 *  **Make better decisions**: Make informed decisions quickly in global teams using **Ideation Blogs** and **Forums**.

For general help on w3 Connections and its features, refer [Using Connections V6][].

## Get Started ##

You can use w3 Connections using the web interface or the mobile app. Get started with w3 Connections on the web, as follows:

1.  [Access w3 Connections][].
2.  Logon using your w3id credentials.

You can set the display language for the masthead, prompts, labels, and titles in w3 Connections from the "Custom Language" drop-down selection on the top-right of the screen. Alternatively, you can set the language from your browser settings.

For information on accessing w3 Connections using the mobile app, refer to Use IBM Connections Mobile App.

## Product Roadmap and Enhancements ##

For product updates relevant to w3 Connections, refer to [Release Plans][].

You can post your ideas, suggestions, and requirements for the product in the [IBM Connections Product Ideas Lab][].

## Entitlement and Cost ##

All IBMers have been provisioned for w3 Connections.

The IBM CIO team absorbs the charge for your usage of this service.

## Get Help ##

If you need help with w3 Connections, use the following support channels:

 *  **Infrastructure issues**: If you can't access w3 Connections while connected to other w3 resources, check for outage announcements on Help@IBM above.
 *  **Known issues**: Refer to [Known Problems of W3 Connections][] for functionality issues.
 *  **How-to questions**: For how-to questions, refer to the following resources:
    
     *  Click the "?" icon on the blue menu bar of any w3 Connections page to access embedded Help: [IBM Connections overview.][]
     *  Use self-help articles listed in the [w3 Connections][w3 Connections 1] category on Help@IBM.
     *  Search for solutions or post new questions on the [w3 Connections Forum.][]

Was this document helpful?

Yes No

19 found this helpful

## Need more help for **W3 Connections**? ##

Contact Support

Get support by phone, chat, web ticket or forum.

Support options available for

Search

 Search

 Search

No matches found

Start typing to see the potential matches...

Recent topics

Oops, there was a problem. Try again later.

 Don’t see the options that you’re looking for?

 

**General support on another topic**

Open the support slide out

## About Help@IBM ##

Please visit the [Help@IBM Community][Help_IBM Community] for:

 *  [Latest Help@IBM news][Latest Help_IBM news]
 *  [Share your experience with other IBMers][]
 *  [Submit and vote on ideas][]

# Content Removed #

##  ##

The topic was removed or is no longer available

OK

# Content Removed #

##  ##

The topic was removed or is no longer available

OK

# Content Removed #

##  ##

The topic was removed or is no longer available

OK


[Go to W3 site _external link]: https://w3.ibm.com/
[Image 1]: 
[My Devices]: https://w3.ibm.com/help/mobile/helpentry.html?redirect_uri=https%3A%2F%2Fw3.ibm.com%2Fhelp%2F%23%2Fmac%2Fus_imt%2Farticle%2Fuse_w3connections%2Foverview
[View as PDF]: https://prdpcrdw3mac.w3-969.ibm.com:443/help/services/content/v1/runtime/composites/pdf/use_w3connections?target=help&language=en&location=/worldwide/north_america_iot/us_imt&platform=/all_platforms/desktop/mac
[w3 Connections]: https://w3-connections.ibm.com
[Using Connections V6]: https://w3-connections.ibm.com/help/SSYGQH_KCCI/welcome/welcome_end_user.html
[Access w3 Connections]: http://w3-connections.ibm.com
[Release Plans]: http://ibm.biz/w3ConnectionsReleasePlans
[IBM Connections Product Ideas Lab]: https://connections.ideas.aha.io/
[Known Problems of W3 Connections]: http://ibm.biz/w3KnownProblems
[IBM Connections overview.]: https://w3-connections.ibm.com/help/index.jsp
[w3 Connections 1]: https://w3.ibm.com/help/#/browse/software_and_hardware/product/collaboration_and_social/w3_connections
[w3 Connections Forum.]: http://ibm.biz/w3ConnectionsSupportForum
[Help_IBM Community]: https://apps.na.collabserv.com/communities/service/html/communitystart?communityUuid=e08d5a18-1566-4dab-af67-528cd935d3fc
[Latest Help_IBM news]: https://apps.na.collabserv.com/wikis/home?lang=en-us#!/wiki/W602679af2a9e_437a_b02e_4719fba6fa3c/page/News
[Share your experience with other IBMers]: https://apps.na.collabserv.com/communities/service/html/communityoverview?communityUuid=e08d5a18-1566-4dab-af67-528cd935d3fc#fullpageWidgetId=Wf02ce5d9291a_44fc_b105_113901f4e3f1
[Submit and vote on ideas]: https://apps.na.collabserv.com/communities/service/html/communityoverview?communityUuid=e08d5a18-1566-4dab-af67-528cd935d3fc#fullpageWidgetId=W12ca17405a67_4449_8bcd_071b93c1509c