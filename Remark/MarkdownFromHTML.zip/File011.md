 Open/Close Main menu

 *  [Go to W3 site (external link)][Go to W3 site _external link]
 *   Help@**IBM**Help@IBM

Search input  Search  Clear

Cancel

Top results

Press Enter to see all  search results

Welcome, Sign In 

 *  
 *   Search
 *   Search
 *  Settings
    
    English  
    Change language
    
     *   Français (Canadien) 
     *   日本語 
    
    ![Image 1][]
    
    United States of America (USA)  
    Change location
    
    Filter by location name×
    
     *  ![Image 1][] Afghanistan
     *  ![Image 1][] Albania
     *  ![Image 1][] Algeria
     *  ![Image 1][] Angola
     *  ![Image 1][] Antigua and Barbuda
     *  ![Image 1][] Argentina
     *  ![Image 1][] Armenia
     *  ![Image 1][] Aruba
     *  ![Image 1][] Australia
     *  ![Image 1][] Austria
     *  ![Image 1][] Azerbaijan
     *  ![Image 1][] Bahamas
     *  ![Image 1][] Bahrain
     *  ![Image 1][] Bangladesh
     *  ![Image 1][] Barbados
     *  ![Image 1][] Belarus
     *  ![Image 1][] Belgium
     *  ![Image 1][] Benin
     *  ![Image 1][] Bermuda
     *  ![Image 1][] Bolivia, Plurinational State of
     *  ![Image 1][] Bosnia and Herzegovina
     *  ![Image 1][] Botswana
     *  ![Image 1][] Brazil (BR)
     *  ![Image 1][] Brunei Darussalam
     *  ![Image 1][] Bulgaria
     *  ![Image 1][] Burkina Faso
     *  ![Image 1][] Burundi
     *  ![Image 1][] Cambodia
     *  ![Image 1][] Cameroon
     *  ![Image 1][] Canada
     *  ![Image 1][] Cape Verde
     *  ![Image 1][] Cayman Islands
     *  ![Image 1][] Central African Republic
     *  ![Image 1][] Chad
     *  ![Image 1][] Chile
     *  ![Image 1][] Colombia
     *  ![Image 1][] Costa Rica
     *  ![Image 1][] Cote d'Ivoire
     *  ![Image 1][] Croatia
     *  ![Image 1][] Cuba
     *  ![Image 1][] Cyprus
     *  ![Image 1][] Czech Republic
     *  ![Image 1][] Denmark
     *  ![Image 1][] Djibouti
     *  ![Image 1][] Dominican Republic
     *  ![Image 1][] Ecuador
     *  ![Image 1][] Egypt
     *  ![Image 1][] El Salvador
     *  ![Image 1][] Equatorial Guinea
     *  ![Image 1][] Eritrea
     *  ![Image 1][] Estonia
     *  ![Image 1][] Ethiopia
     *  ![Image 1][] Faroe Islands
     *  ![Image 1][] Finland
     *  ![Image 1][] France
     *  ![Image 1][] French Guiana
     *  ![Image 1][] French Polynesia
     *  ![Image 1][] Gabon
     *  ![Image 1][] Gambia
     *  ![Image 1][] Georgia
     *  ![Image 1][] Germany
     *  ![Image 1][] Ghana
     *  ![Image 1][] Greece
     *  ![Image 1][] Greenland
     *  ![Image 1][] Guadeloupe
     *  ![Image 1][] Guam
     *  ![Image 1][] Guatemala
     *  ![Image 1][] Guinea
     *  ![Image 1][] Guinea-Bissau
     *  ![Image 1][] Guyana
     *  ![Image 1][] Haiti
     *  ![Image 1][] Honduras
     *  ![Image 1][] Hong Kong
     *  ![Image 1][] Hungary
     *  ![Image 1][] Iceland
     *  ![Image 1][] India
     *  ![Image 1][] India-South Asia IMT
     *  ![Image 1][] Indonesia
     *  ![Image 1][] Iran, Islamic Republic of
     *  ![Image 1][] Iraq
     *  ![Image 1][] Ireland
     *  ![Image 1][] Israel
     *  ![Image 1][] Italy
     *  ![Image 1][] Jamaica
     *  ![Image 1][] Japan
     *  ![Image 1][] Jordan
     *  ![Image 1][] Kazakhstan
     *  ![Image 1][] Kenya
     *  ![Image 1][] Korea, Republic of
     *  ![Image 1][] Kuwait
     *  ![Image 1][] Kyrgyzstan
     *  ![Image 1][] Lao People's Democratic Republic
     *  ![Image 1][] Latvia
     *  ![Image 1][] Lebanon
     *  ![Image 1][] Lesotho
     *  ![Image 1][] Liberia
     *  ![Image 1][] Libya
     *  ![Image 1][] Lithuania
     *  ![Image 1][] Luxembourg
     *  ![Image 1][] Macao
     *  ![Image 1][] Macedonia, The former Yugoslav Republic of
     *  ![Image 1][] Madagascar
     *  ![Image 1][] Malawi
     *  ![Image 1][] Malaysia
     *  ![Image 1][] Mali
     *  ![Image 1][] Malta
     *  ![Image 1][] Mauritania
     *  ![Image 1][] Mauritius
     *  ![Image 1][] Mexico (MX)
     *  ![Image 1][] Moldova, Republic of
     *  ![Image 1][] Morocco
     *  ![Image 1][] Mozambique
     *  ![Image 1][] Namibia
     *  ![Image 1][] Nepal
     *  ![Image 1][] Netherlands
     *  ![Image 1][] New Caledonia
     *  ![Image 1][] New Zealand
     *  ![Image 1][] Nicaragua
     *  ![Image 1][] Niger
     *  ![Image 1][] Nigeria
     *  ![Image 1][] Norway
     *  ![Image 1][] Oman
     *  ![Image 1][] Pakistan
     *  ![Image 1][] Panama
     *  ![Image 1][] Paraguay
     *  ![Image 1][] Peru
     *  ![Image 1][] Philippines
     *  ![Image 1][] Poland
     *  ![Image 1][] Portugal
     *  ![Image 1][] Puerto Rico
     *  ![Image 1][] Qatar
     *  ![Image 1][] Romania
     *  ![Image 1][] Russian Federation
     *  ![Image 1][] Rwanda
     *  ![Image 1][] Saint Lucia
     *  ![Image 1][] Sao Tome and Principe
     *  ![Image 1][] Saudi Arabia
     *  ![Image 1][] Senegal
     *  ![Image 1][] Serbia
     *  ![Image 1][] Sierra Leone
     *  ![Image 1][] Singapore
     *  ![Image 1][] Slovakia
     *  ![Image 1][] Slovenia
     *  ![Image 1][] Somalia
     *  ![Image 1][] South Africa (ZA)
     *  ![Image 1][] Spain
     *  ![Image 1][] Sri Lanka
     *  ![Image 1][] Sudan
     *  ![Image 1][] Suriname
     *  ![Image 1][] Svalbard and Jan Mayen
     *  ![Image 1][] Swaziland
     *  ![Image 1][] Sweden
     *  ![Image 1][] Switzerland
     *  ![Image 1][] Taiwan
     *  ![Image 1][] Tajikistan
     *  ![Image 1][] Tanzania, United Republic of
     *  ![Image 1][] Thailand
     *  ![Image 1][] The Peoples Rep of China
     *  ![Image 1][] Trinidad and Tobago
     *  ![Image 1][] Tunisia
     *  ![Image 1][] Turkey (TR)
     *  ![Image 1][] Turkmenistan
     *  ![Image 1][] Uganda
     *  ![Image 1][] Ukraine
     *  ![Image 1][] United Arab Emirates (UAE)
     *  ![Image 1][] United Kingdom (UK)
     *  ![Image 1][] Uruguay
     *  ![Image 1][] Uzbekistan
     *  ![Image 1][] Venezuela, Bolivarian Republic of
     *  ![Image 1][] Viet Nam
     *  ![Image 1][] Virgin Islands, U.S.
     *  ![Image 1][] Yemen
     *  ![Image 1][] Zambia
     *  ![Image 1][] Zimbabwe
    
    Default![Image 1][] Change theme
    
     *  Contrast![Image 1][]
     *  Low-light![Image 1][]
 *  ![Image 1][] Showing content for United States of America (USA). Change country

 *    Home
 *    Top Issues
 *    Products
 *    All Outages
 *    My Tickets
 *  [  My Devices][My Devices]
 *  
 *    Settings

 w3

Search input

[yourIBM][Go to W3 site _external link]

 You must enable Javascript for Help@IBM to work properly.

![platform][Image 1] Mac  Currently selected platform

###  ###

### Your Platform ###

Your current platform is Mac. You can change it here any time.

Got it!

![platform][Image 1] Mac Currently selected platform

###  ###

### Your Platform ###

Your current platform is Mac. You can change it here any time.

Got it!

Products

 *    Home
 *    Top Issues
 *    Productsactive
 *    All Outages
 *    My Tickets
 *  [  My Devices][My Devices]

 *  ![platform][Image 1] Windows 7
 *  ![platform][Image 1] Windows 10
 *  ![platform][Image 1] Linux
 *  ![platform][Image 1] iOS
 *  ![platform][Image 1] Android

 *  Contact Support

Select Platform

 *  ![platform][Image 1]
    
    Windows 7
 *  ![platform][Image 1]
    
    Windows 10
 *  ![platform][Image 1]
    
    Linux
 *  ![platform][Image 1]
    
    iOS
 *  ![platform][Image 1]
    
    Android
 *  ![platform][Image 1]
    
    MacCurrently selected platform

 *  Mail@IBM
 *  IBM Verse

# Access Delegated Mail and Calendar on the Cloud #

Actions

[View as PDF][]

Copied to clipboard

Input with selected link to share Links to share

 *  https://w3.ibm.com/help/\#/article/39470Without personalization
 *  https://w3.ibm.com/help/\#/mac/us\_imt/en/article/39470 With personalization (Mac, English, )

Copy

Using IBM Notes  Toggle visibility of the chapters menu.

 *  Overview
 *  Using IBM Notes
 *  Using SmartCloud Notes Web
 *  Using IBM Verse

## Using IBM Notes ##

There are multiple options to access delegated mail and calendar using IBM Notes.

 *  [Use the Notes Toolbox][]
 *  [Use the Notes Other Mail View][]
 *  [Use the Notes Calendar view][]
 *  [Create a Bookmark to Delegated Mail][]
 *  [Create Other Mail Links to Delegated Mail][]

 

## Use the Notes Toolbox ##

The IBM Notes Toolbox allows you to locate information about your mail client and perform some Notes functions with a single click. The example below provides the steps to access delegated mail or calendar in Notes.

1.  Open Notes if it isn't already.
2.  Click this link to Open another persons Mail or Calendar that you have been delegated access to in Notes.
3.  Click the button to open a mail or calendar you have been delegated access to.
4.  Enter the User ID (e.g., IBM User/Somers/IBM), and then click OK.
5.  Enter the User ID (e.g., IBM User/Somers/IBM) and click OK.  
    ![ithc_39470_Openanotherpersonsmail3_0.png][]

 

## Use the Notes Other Mail View ##

1.  In your Notes Inbox view, expand the Other Mail section and click Open Other Mail.  
    ![ithc_39470_openothermail1.png][]
2.  In the Directory field, select Company Directory.
3.  In the "Find names starting with" field enter your principal's fully qualified name in the form of "last name , first name". Be sure to leave a space before and after the comma separator.
4.  Select the principal's mailbox from the list and click OK.  
    ​![ithc_39470_Companydirmain.png][]

 

## Use the Notes Calendar View ##

1.  Click More at the top of the calendar.
2.  Click Open Person's Calendar.  
    ![ithc_39470_Accesscalendar.jpg][]
3.  In the Directory field, select Company Directory.  
    **Note:** In the Verse deployment, Company Directory combines all the server address books, e.g., IBM directory, Extended Directory Catalog, WWPDL, etc.  
    In the "Find names starting with" field, enter the principal's fully qualified name in the form of "last name , first name". Be sure to leave a space before and after the comma separator.
4.  Select the user name and click OK.  
    ![ithc_39470_Companydirmain.png][]

 

## Create a Bookmark to Delegated Mail ##

For ease of future access, create a bookmark to the delegated mail or calendar in the Open list:

1.  Right-click on the tab for the Delegated Mail or Calendar, and select Create Bookmark.
2.  Select Bookmark Bar, and then click OK.

A link is added in the Open list.

 

## Create Other Mail Links to Delegated Mail ##

For ease of future access, you can create shortcuts to the delegated mail location.

1.  From the File menu, select Preferences.
2.  Expand "Calendar and To Do." select "Access and Delegation," and then click the Access & Delegation tab.  
    ![ithc_39470_AccessandDel2.jpg][]
3.  Click the "Shortcuts to Others' Mail" tab.  
    ![ithc_39470_AccessandDel3.jpg][]
4.  Under "Create shortcuts to open the mail files of these people" type the names of people who have delegated access to their mailbox to you and whose mailboxes have recently been moved to the cloud. To select names from a directory, click the arrow to the right of the field.
    
    **Note:** This creates shortcuts to that person's Mail, Calendar, and To Do's.
5.  Open delegated Mail/Calendar from the shortcut that begins with NALLN. You can access their Mail, Calendar, and To Do's from within your Mail/Calendar/To Do's interface or from within your Notes Desktop, as earlier. The shortcut will display in the navigation pane of your mail under Other Mail, in the navigation pane of your calendar under Show Calendars, and in the navigation pane of To Do under Other To Do.  
    ![notes_delegated_other_mail.png][]

Was this document helpful?

Yes No

26 found this helpful

## Need more help for **IBM Verse**? ##

Contact Support

Get support by phone, chat, web ticket or forum.

Support options available for

Search

 Search

 Search

No matches found

Start typing to see the potential matches...

Recent topics

General 

Verse Mobile App

Oops, there was a problem. Try again later.

 Don’t see the options that you’re looking for?

 

**General support on another topic**

Open the support slide out

## About Help@IBM ##

Please visit the [Help@IBM Community][Help_IBM Community] for:

 *  [Latest Help@IBM news][Latest Help_IBM news]
 *  [Share your experience with other IBMers][]
 *  [Submit and vote on ideas][]

# Content Removed #

##  ##

The topic was removed or is no longer available

OK

# Content Removed #

##  ##

The topic was removed or is no longer available

OK

# Content Removed #

##  ##

The topic was removed or is no longer available

OK


[Go to W3 site _external link]: https://w3.ibm.com/
[Image 1]: 
[My Devices]: https://w3.ibm.com/help/mobile/helpentry.html?redirect_uri=https%3A%2F%2Fw3.ibm.com%2Fhelp%2F%23%2Fmac%2Fus_imt%2Farticle%2F39470%2Faccess_delegated_mail_notes%3Frequestedtopicid%3Daccess_delegated_mail_verse
[View as PDF]: https://prdpcrdw3mac.w3-969.ibm.com:443/help/services/content/v1/runtime/composites/pdf/39470?target=help&language=en&location=/worldwide/north_america_iot/us_imt&platform=/all_platforms/desktop/mac
[Use the Notes Toolbox]: https://w3.ibm.com/help/#/article/39470/access_delegated_mail_notes?requestedTopicId=access_delegated_mail_notes&requestedtopicid=access_delegated_mail_verse&section=notes_toolbox
[Use the Notes Other Mail View]: https://w3.ibm.com/help/#/article/39470/access_delegated_mail_notes?requestedTopicId=access_delegated_mail_notes&requestedtopicid=access_delegated_mail_verse&section=notes_other_mail
[Use the Notes Calendar view]: https://w3.ibm.com/help/#/article/39470/access_delegated_mail_notes?requestedTopicId=access_delegated_mail_notes&requestedtopicid=access_delegated_mail_verse&section=notes_calendar
[Create a Bookmark to Delegated Mail]: https://w3.ibm.com/help/#/article/39470/access_delegated_mail_notes?requestedTopicId=access_delegated_mail_notes&requestedtopicid=access_delegated_mail_verse&section=bookmark
[Create Other Mail Links to Delegated Mail]: https://w3.ibm.com/help/#/article/39470/access_delegated_mail_notes?requestedTopicId=access_delegated_mail_notes&requestedtopicid=access_delegated_mail_verse&section=shortcuts
[ithc_39470_Openanotherpersonsmail3_0.png]: https://prd1pcrdw3mac.w3-969.ibm.com/help/static/ithc_39470_Openanotherpersonsmail3_0/en/ithc_39470_Openanotherpersonsmail3_0.png
[ithc_39470_openothermail1.png]: https://prd1pcrdw3mac.w3-969.ibm.com/help/static/ithc_39470_openothermail1/en/ithc_39470_openothermail1.png
[ithc_39470_Companydirmain.png]: https://prd1pcrdw3mac.w3-969.ibm.com/help/static/ithc_39470_Companydirmain/en/ithc_39470_Companydirmain.png
[ithc_39470_Accesscalendar.jpg]: https://prd1pcrdw3mac.w3-969.ibm.com/help/static/ithc_39470_Accesscalendar/en/ithc_39470_Accesscalendar.jpg
[ithc_39470_AccessandDel2.jpg]: https://prd1pcrdw3mac.w3-969.ibm.com/help/static/ithc_39470_AccessandDel2/en/ithc_39470_AccessandDel2.jpg
[ithc_39470_AccessandDel3.jpg]: https://prd1pcrdw3mac.w3-969.ibm.com/help/static/ithc_39470_AccessandDel3/en/ithc_39470_AccessandDel3.jpg
[notes_delegated_other_mail.png]: https://prd1pcrdw3mac.w3-969.ibm.com/help/static/notes_delegated_other_mail/en/notes_delegated_other_mail.png
[Help_IBM Community]: https://apps.na.collabserv.com/communities/service/html/communitystart?communityUuid=e08d5a18-1566-4dab-af67-528cd935d3fc
[Latest Help_IBM news]: https://apps.na.collabserv.com/wikis/home?lang=en-us#!/wiki/W602679af2a9e_437a_b02e_4719fba6fa3c/page/News
[Share your experience with other IBMers]: https://apps.na.collabserv.com/communities/service/html/communityoverview?communityUuid=e08d5a18-1566-4dab-af67-528cd935d3fc#fullpageWidgetId=Wf02ce5d9291a_44fc_b105_113901f4e3f1
[Submit and vote on ideas]: https://apps.na.collabserv.com/communities/service/html/communityoverview?communityUuid=e08d5a18-1566-4dab-af67-528cd935d3fc#fullpageWidgetId=W12ca17405a67_4449_8bcd_071b93c1509c