 Open/Close Main menu

 *  [Go to W3 site (external link)][Go to W3 site _external link]
 *   Help@**IBM**Help@IBM

Search input  Search  Clear

Cancel

Top results

Press Enter to see all  search results

Welcome, Sign In 

 *  
 *   Search
 *   Search
 *  Settings
    
    English  
    Change language
    
     *   Français (Canadien) 
     *   日本語 
    
    ![Image 1][]
    
    United States of America (USA)  
    Change location
    
    Filter by location name×
    
     *  ![Image 1][] Afghanistan
     *  ![Image 1][] Albania
     *  ![Image 1][] Algeria
     *  ![Image 1][] Angola
     *  ![Image 1][] Antigua and Barbuda
     *  ![Image 1][] Argentina
     *  ![Image 1][] Armenia
     *  ![Image 1][] Aruba
     *  ![Image 1][] Australia
     *  ![Image 1][] Austria
     *  ![Image 1][] Azerbaijan
     *  ![Image 1][] Bahamas
     *  ![Image 1][] Bahrain
     *  ![Image 1][] Bangladesh
     *  ![Image 1][] Barbados
     *  ![Image 1][] Belarus
     *  ![Image 1][] Belgium
     *  ![Image 1][] Benin
     *  ![Image 1][] Bermuda
     *  ![Image 1][] Bolivia, Plurinational State of
     *  ![Image 1][] Bosnia and Herzegovina
     *  ![Image 1][] Botswana
     *  ![Image 1][] Brazil (BR)
     *  ![Image 1][] Brunei Darussalam
     *  ![Image 1][] Bulgaria
     *  ![Image 1][] Burkina Faso
     *  ![Image 1][] Burundi
     *  ![Image 1][] Cambodia
     *  ![Image 1][] Cameroon
     *  ![Image 1][] Canada
     *  ![Image 1][] Cape Verde
     *  ![Image 1][] Cayman Islands
     *  ![Image 1][] Central African Republic
     *  ![Image 1][] Chad
     *  ![Image 1][] Chile
     *  ![Image 1][] Colombia
     *  ![Image 1][] Costa Rica
     *  ![Image 1][] Cote d'Ivoire
     *  ![Image 1][] Croatia
     *  ![Image 1][] Cuba
     *  ![Image 1][] Cyprus
     *  ![Image 1][] Czech Republic
     *  ![Image 1][] Denmark
     *  ![Image 1][] Djibouti
     *  ![Image 1][] Dominican Republic
     *  ![Image 1][] Ecuador
     *  ![Image 1][] Egypt
     *  ![Image 1][] El Salvador
     *  ![Image 1][] Equatorial Guinea
     *  ![Image 1][] Eritrea
     *  ![Image 1][] Estonia
     *  ![Image 1][] Ethiopia
     *  ![Image 1][] Faroe Islands
     *  ![Image 1][] Finland
     *  ![Image 1][] France
     *  ![Image 1][] French Guiana
     *  ![Image 1][] French Polynesia
     *  ![Image 1][] Gabon
     *  ![Image 1][] Gambia
     *  ![Image 1][] Georgia
     *  ![Image 1][] Germany
     *  ![Image 1][] Ghana
     *  ![Image 1][] Greece
     *  ![Image 1][] Greenland
     *  ![Image 1][] Guadeloupe
     *  ![Image 1][] Guam
     *  ![Image 1][] Guatemala
     *  ![Image 1][] Guinea
     *  ![Image 1][] Guinea-Bissau
     *  ![Image 1][] Guyana
     *  ![Image 1][] Haiti
     *  ![Image 1][] Honduras
     *  ![Image 1][] Hong Kong
     *  ![Image 1][] Hungary
     *  ![Image 1][] Iceland
     *  ![Image 1][] India
     *  ![Image 1][] India-South Asia IMT
     *  ![Image 1][] Indonesia
     *  ![Image 1][] Iran, Islamic Republic of
     *  ![Image 1][] Iraq
     *  ![Image 1][] Ireland
     *  ![Image 1][] Israel
     *  ![Image 1][] Italy
     *  ![Image 1][] Jamaica
     *  ![Image 1][] Japan
     *  ![Image 1][] Jordan
     *  ![Image 1][] Kazakhstan
     *  ![Image 1][] Kenya
     *  ![Image 1][] Korea, Republic of
     *  ![Image 1][] Kuwait
     *  ![Image 1][] Kyrgyzstan
     *  ![Image 1][] Lao People's Democratic Republic
     *  ![Image 1][] Latvia
     *  ![Image 1][] Lebanon
     *  ![Image 1][] Lesotho
     *  ![Image 1][] Liberia
     *  ![Image 1][] Libya
     *  ![Image 1][] Lithuania
     *  ![Image 1][] Luxembourg
     *  ![Image 1][] Macao
     *  ![Image 1][] Macedonia, The former Yugoslav Republic of
     *  ![Image 1][] Madagascar
     *  ![Image 1][] Malawi
     *  ![Image 1][] Malaysia
     *  ![Image 1][] Mali
     *  ![Image 1][] Malta
     *  ![Image 1][] Mauritania
     *  ![Image 1][] Mauritius
     *  ![Image 1][] Mexico (MX)
     *  ![Image 1][] Moldova, Republic of
     *  ![Image 1][] Morocco
     *  ![Image 1][] Mozambique
     *  ![Image 1][] Namibia
     *  ![Image 1][] Nepal
     *  ![Image 1][] Netherlands
     *  ![Image 1][] New Caledonia
     *  ![Image 1][] New Zealand
     *  ![Image 1][] Nicaragua
     *  ![Image 1][] Niger
     *  ![Image 1][] Nigeria
     *  ![Image 1][] Norway
     *  ![Image 1][] Oman
     *  ![Image 1][] Pakistan
     *  ![Image 1][] Panama
     *  ![Image 1][] Paraguay
     *  ![Image 1][] Peru
     *  ![Image 1][] Philippines
     *  ![Image 1][] Poland
     *  ![Image 1][] Portugal
     *  ![Image 1][] Puerto Rico
     *  ![Image 1][] Qatar
     *  ![Image 1][] Romania
     *  ![Image 1][] Russian Federation
     *  ![Image 1][] Rwanda
     *  ![Image 1][] Saint Lucia
     *  ![Image 1][] Sao Tome and Principe
     *  ![Image 1][] Saudi Arabia
     *  ![Image 1][] Senegal
     *  ![Image 1][] Serbia
     *  ![Image 1][] Sierra Leone
     *  ![Image 1][] Singapore
     *  ![Image 1][] Slovakia
     *  ![Image 1][] Slovenia
     *  ![Image 1][] Somalia
     *  ![Image 1][] South Africa (ZA)
     *  ![Image 1][] Spain
     *  ![Image 1][] Sri Lanka
     *  ![Image 1][] Sudan
     *  ![Image 1][] Suriname
     *  ![Image 1][] Svalbard and Jan Mayen
     *  ![Image 1][] Swaziland
     *  ![Image 1][] Sweden
     *  ![Image 1][] Switzerland
     *  ![Image 1][] Taiwan
     *  ![Image 1][] Tajikistan
     *  ![Image 1][] Tanzania, United Republic of
     *  ![Image 1][] Thailand
     *  ![Image 1][] The Peoples Rep of China
     *  ![Image 1][] Trinidad and Tobago
     *  ![Image 1][] Tunisia
     *  ![Image 1][] Turkey (TR)
     *  ![Image 1][] Turkmenistan
     *  ![Image 1][] Uganda
     *  ![Image 1][] Ukraine
     *  ![Image 1][] United Arab Emirates (UAE)
     *  ![Image 1][] United Kingdom (UK)
     *  ![Image 1][] Uruguay
     *  ![Image 1][] Uzbekistan
     *  ![Image 1][] Venezuela, Bolivarian Republic of
     *  ![Image 1][] Viet Nam
     *  ![Image 1][] Virgin Islands, U.S.
     *  ![Image 1][] Yemen
     *  ![Image 1][] Zambia
     *  ![Image 1][] Zimbabwe
    
    Default![Image 1][] Change theme
    
     *  Contrast![Image 1][]
     *  Low-light![Image 1][]
 *  ![Image 1][] Showing content for United States of America (USA). Change country

 *    Home
 *    Top Issues
 *    Products
 *    All Outages
 *    My Tickets
 *  [  My Devices][My Devices]
 *  
 *    Settings

 w3

Search input

[yourIBM][Go to W3 site _external link]

 You must enable Javascript for Help@IBM to work properly.

![platform][Image 1] Mac  Currently selected platform

###  ###

### Your Platform ###

Your current platform is Mac. You can change it here any time.

Got it!

![platform][Image 1] Mac Currently selected platform

###  ###

### Your Platform ###

Your current platform is Mac. You can change it here any time.

Got it!

Home

 *    Homeactive
 *    Top Issues
 *    Products
 *    All Outages
 *    My Tickets
 *  [  My Devices][My Devices]

 *  ![platform][Image 1] Windows 7
 *  ![platform][Image 1] Windows 10
 *  ![platform][Image 1] Linux
 *  ![platform][Image 1] iOS
 *  ![platform][Image 1] Android

 *  Contact Support

Select Platform

 *  ![platform][Image 1]
    
    Windows 7
 *  ![platform][Image 1]
    
    Windows 10
 *  ![platform][Image 1]
    
    Linux
 *  ![platform][Image 1]
    
    iOS
 *  ![platform][Image 1]
    
    Android
 *  ![platform][Image 1]
    
    MacCurrently selected platform

Outage:

Outage:Print@IBM Americas will be down during scheduled weekend maintenance window for 2 hrsView

 Details  

 Close 

<table>
 <tbody>
  <tr>
   <th>Outage Name</th>
   <th>Type</th>
   <th>Start Time</th>
   <th>Estimated Fix</th>
  </tr> 
  <tr>
   <td><a rel="nofollow">Print@IBM Americas will be down during scheduled weekend maintenance window for 2 hrs</a></td>
   <td>Planned</td>
   <td><span>10 Aug 2019</span>11:00 PM </td>
   <td>11 Aug 2019 1:00 AM EDT</td>
  </tr> 
 </tbody>
</table>

Only outages for the most common systems in your location are displayed here. View All outages for a complete list of worldwide outages.

6 Help Advisor Alerts.w3id Single Sign-on (SSO), W3 Enterprise Search, Ethernet & LAN, Windows 10, Secure Access Services (SAS). Close   Details 

 Details 

 Close 

 *  Information for Web Applications that receive "Secure Connection Failed" after August 11th
    
    If a user accessing web applications (including the w3id Profile for Password Management application at [https://w3.ibm.com/password][https_w3.ibm.com_password] or [https://w3idprofile.sso.ibm.com/password][https_w3idprofile.sso.ibm.com_password]) receives a "Secure Connection Failed" message after the August 11th w3id SSO change to disable older Transport Layer Security (TLS) versions 1.0 and 1.1, it may mean that an older browser is being used.
    
     
    
    **Action: ** users may need to update to the latest browser version which supports TLS v1.2.
    
     
    
    More information and details are posted here:  [https://w3-connections.ibm.com/wikis/home?lang=en-us\#!/wiki/W89b23bf7ad80\_4411\_822f\_2a6dc171c6b3/page/TLS%201.0%20and%201.1%20Browser%20Errors][https_w3-connections.ibm.com_wikis_home_lang_en-us_wiki_W89b23bf7ad80_4411_822f_2a6dc171c6b3_page_TLS_201.0_20and_201.1_20Browser_20Errors]
 *  w3id Single Sign On (SSO) to Disable Transport Layer Security (TLS) v1 and v1.1 in production on August 11th.
    
    **Subject**:  w3id Single Sign On (SSO) to Disable Transport Layer Security (TLS) v1 and v1.1 in production on **August 11th**.  
      
    This announcement has been sent to all OpenID Connect (OIDC) and Security Assertion Markup Language (SAML) adopters since July 12th (reminders are being sent).
    
     
    
    **Why?**
    
    In May, the Mixed Address Database (MAD) Scanner was updated to identify infrastructure with TLS v1.0 and v1.1 enabled as low severity vulnerabilities. Section 6.7.3 of the IT Security Standard (ITSS) requires low vulnerabilities to be address within 90 days for internal assets and 30 days for internet facing assets.  As [announced in the w3id SSO forum][] [https://w3-connections.ibm.com/forums/html/topic?id=312d26dd-a203-4578-941c-680431f1c55b&ps=100][announced in the w3id SSO forum]these protocols will be disabled in Production on **August 11th**. The testing and staging environments will be also affected.  The schedule is provided below.  
      
    **Impacted applications**
    
    Applications using the OpenID Connect protocol, that call the /introspect or /token endpoints and do not have TLS v1.2  enabled.  
     
    
    **Applications that are not impacted**
    
    ⦁    Applications using the SAML protocol and implicit OpenID Connect will not be impacted as all connections originate from the end user's browser.
    
    ⦁    Third party applications using SAML 2 will not be impacted by this change.  (i.e. Box, Office 365, Workday, WebEx, Slack, etc.) .  
      
    **When?**
    
    The change will be deployed in **Production** on **August 11th**.
    
     
    
    <table style="border-collapse:collapse; border:ridge windowtext 2.25pt"> 
     <tbody> 
      <tr> 
       <td style="width:153.0pt; border:ridge windowtext 2.25pt"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><b><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">w3id Environment</span></span></span></b></span></span></span></p> </td> 
       <td style="width:179.25pt; border:ridge windowtext 2.25pt; border-left:none"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><b><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">Hostname</span></span></span></b></span></span></span></p> </td> 
       <td style="width:144.75pt; border:ridge windowtext 2.25pt; border-left:none"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><b><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">Deployment Date</span></span></span></b></span></span></span></p> </td> 
      </tr> 
      <tr> 
       <td style="width:153.0pt; border:ridge windowtext 2.25pt; border-top:none"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">Test</span></span></span></span></span></span></p> </td> 
       <td style="width:179.25pt; border-top:none; border-left:none; border-bottom:ridge windowtext 2.25pt; border-right:ridge windowtext 2.25pt"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">w3id-test.sso.ibm.com</span></span></span></span></span></span></p> </td> 
       <td style="width:144.75pt; border-top:none; border-left:none; border-bottom:ridge windowtext 2.25pt; border-right:ridge windowtext 2.25pt"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">July 16th</span></span></span></span></span></span></p> </td> 
      </tr> 
      <tr> 
       <td style="width:153.0pt; border:ridge windowtext 2.25pt; border-top:none"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">Staging</span></span></span></span></span></span></p> </td> 
       <td style="width:179.25pt; border-top:none; border-left:none; border-bottom:ridge windowtext 2.25pt; border-right:ridge windowtext 2.25pt"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">w3id.alpha.sso.ibm.com</span></span></span></span></span></span></p> </td> 
       <td style="width:144.75pt; border-top:none; border-left:none; border-bottom:ridge windowtext 2.25pt; border-right:ridge windowtext 2.25pt"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">July 23rd</span></span></span></span></span></span></p> </td> 
      </tr> 
      <tr> 
       <td style="width:153.0pt; border:ridge windowtext 2.25pt; border-top:none; background:#00a1e0"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><b><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:white">Production</span></span></span></b></span></span></span></p> </td> 
       <td style="width:179.25pt; border-top:none; border-left:none; border-bottom:ridge windowtext 2.25pt; border-right:ridge windowtext 2.25pt; background:#00a1e0"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><b><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:white">w3id.sso.ibm.com</span></span></span></b></span></span></span></p> </td> 
       <td style="width:144.75pt; border-top:none; border-left:none; border-bottom:ridge windowtext 2.25pt; border-right:ridge windowtext 2.25pt; background:#00a1e0"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><b><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:white">August 11th</span></span></span></b></span></span></span></p> </td> 
      </tr> 
     </tbody> 
    </table>
    
     
    
    **What do I need to do?**
    
    **To avoid disruption in service**, applications must ensure that TLS v1.2 is enabled. Failure to take action will lead to an application outage on or after the deployment date.
    
      
    **How to list your applications**
    
    Follow [these steps][]
    
    ([https://w3-connections.ibm.com/wikis/home?lang=en-us\#!/wiki/W89b23bf7ad80\_4411\_822f\_2a6dc171c6b3/page/How%20to%20list%20your%20applications%20and%20remove%20as%20needed][these steps]) to list your applications.
    
    **Support**
    
    ⦁    If you have questions, please post to the [Enterprise and Technology Security Vulnerability Management Community. ][Enterprise and Technology Security Vulnerability Management Community.]  
    ⦁    Please do not post detection and remediation questions to the w3id SSO forum.
 *  Unused Ethernet ports in IBM Office space will be deactivated
    
    Unused Office space Ethernet ports will be deactivated.  If an active device has not been connected to it in the past 75 days, then it will be deactivated.  This mainly affects ports in office, agile areas and conference rooms.  This will not affect ports in private labs.  CIO managed devices can connect to IBM WiFi where connectivity is needed and Ethernet ports are not available or active.  If someone needs to reactivate the Ethernet LAN Port for a CIO managed device, please follow the instructions provided in the section "Reactivate a LAN Port" given in the following URL -**[https://w3.ibm.com/help/\#/article/25139][https_w3.ibm.com_help_article_25139]**
 *  Windows 10 VPN certificates will now automatically be delivered
    
    During the initial Windows 10 setup you will no longer need to "Get VPN Cert" as the VPN certificate will automatically be delivered to your PC.  
    For more information refer to either Help@IBM  [Set Up a PC][] or in the [Windows 10 install Guide][].
 *  WECM (IBM Mobility Client) service decommission alert
    
    Audience: IBM employees using IBM Mobility Client (WECM VPN) for remote access to IBM network.
    
    What's happening? - WECM/IMC software has reached end of life and the extended support agreement will end mid-year. The service will be discontinued by August 31st, 2019. Windows 7 systems within IBM are being migrated to either Windows 10, macOS or Linux, and SAS VPN (based on Cisco AnyConnect) provides remote access for those operating systems. If you are migrated to a new Windows 10, macOS or Linux machine prior to August 1st, SAS VPN will be available to you at installation time.
    
    If you're connecting today with IBM Mobility Client, and will remain on Windows 7 after August 1st, you must migrate to Cisco AnyConnect for Windows 7 using these instructions: [https://w3.ibm.com/help/\#/article/connect\_from\_remote\_location/connect\_from\_remote\_location\_overview ][https_w3.ibm.com_help_article_connect_from_remote_location_connect_from_remote_location_overview]
 *  Microsoft Teams app auto start feature removed by IBM policy
    
    The **"auto start with Windows"** functionality of unsupported app Microsoft Teams has been disabled by IBM policy effective 8/6/19. This does not impact app usability or function.

 *  Information for Web Applications that receive "Secure Connection Failed" after August 11th
    
    If a user accessing web applications (including the w3id Profile for Password Management application at [https://w3.ibm.com/password][https_w3.ibm.com_password] or [https://w3idprofile.sso.ibm.com/password][https_w3idprofile.sso.ibm.com_password]) receives a "Secure Connection Failed" message after the August 11th w3id SSO change to disable older Transport Layer Security (TLS) versions 1.0 and 1.1, it may mean that an older browser is being used.
    
     
    
    **Action: ** users may need to update to the latest browser version which supports TLS v1.2.
    
     
    
    More information and details are posted here:  [https://w3-connections.ibm.com/wikis/home?lang=en-us\#!/wiki/W89b23bf7ad80\_4411\_822f\_2a6dc171c6b3/page/TLS%201.0%20and%201.1%20Browser%20Errors][https_w3-connections.ibm.com_wikis_home_lang_en-us_wiki_W89b23bf7ad80_4411_822f_2a6dc171c6b3_page_TLS_201.0_20and_201.1_20Browser_20Errors]
 *  w3id Single Sign On (SSO) to Disable Transport Layer Security (TLS) v1 and v1.1 in production on August 11th.
    
    **Subject**:  w3id Single Sign On (SSO) to Disable Transport Layer Security (TLS) v1 and v1.1 in production on **August 11th**.  
      
    This announcement has been sent to all OpenID Connect (OIDC) and Security Assertion Markup Language (SAML) adopters since July 12th (reminders are being sent).
    
     
    
    **Why?**
    
    In May, the Mixed Address Database (MAD) Scanner was updated to identify infrastructure with TLS v1.0 and v1.1 enabled as low severity vulnerabilities. Section 6.7.3 of the IT Security Standard (ITSS) requires low vulnerabilities to be address within 90 days for internal assets and 30 days for internet facing assets.  As [announced in the w3id SSO forum][] [https://w3-connections.ibm.com/forums/html/topic?id=312d26dd-a203-4578-941c-680431f1c55b&ps=100][announced in the w3id SSO forum]these protocols will be disabled in Production on **August 11th**. The testing and staging environments will be also affected.  The schedule is provided below.  
      
    **Impacted applications**
    
    Applications using the OpenID Connect protocol, that call the /introspect or /token endpoints and do not have TLS v1.2  enabled.  
     
    
    **Applications that are not impacted**
    
    ⦁    Applications using the SAML protocol and implicit OpenID Connect will not be impacted as all connections originate from the end user's browser.
    
    ⦁    Third party applications using SAML 2 will not be impacted by this change.  (i.e. Box, Office 365, Workday, WebEx, Slack, etc.) .  
      
    **When?**
    
    The change will be deployed in **Production** on **August 11th**.
    
     
    
    <table style="border-collapse:collapse; border:ridge windowtext 2.25pt"> 
     <tbody> 
      <tr> 
       <td style="width:153.0pt; border:ridge windowtext 2.25pt"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><b><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">w3id Environment</span></span></span></b></span></span></span></p> </td> 
       <td style="width:179.25pt; border:ridge windowtext 2.25pt; border-left:none"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><b><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">Hostname</span></span></span></b></span></span></span></p> </td> 
       <td style="width:144.75pt; border:ridge windowtext 2.25pt; border-left:none"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><b><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">Deployment Date</span></span></span></b></span></span></span></p> </td> 
      </tr> 
      <tr> 
       <td style="width:153.0pt; border:ridge windowtext 2.25pt; border-top:none"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">Test</span></span></span></span></span></span></p> </td> 
       <td style="width:179.25pt; border-top:none; border-left:none; border-bottom:ridge windowtext 2.25pt; border-right:ridge windowtext 2.25pt"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">w3id-test.sso.ibm.com</span></span></span></span></span></span></p> </td> 
       <td style="width:144.75pt; border-top:none; border-left:none; border-bottom:ridge windowtext 2.25pt; border-right:ridge windowtext 2.25pt"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">July 16th</span></span></span></span></span></span></p> </td> 
      </tr> 
      <tr> 
       <td style="width:153.0pt; border:ridge windowtext 2.25pt; border-top:none"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">Staging</span></span></span></span></span></span></p> </td> 
       <td style="width:179.25pt; border-top:none; border-left:none; border-bottom:ridge windowtext 2.25pt; border-right:ridge windowtext 2.25pt"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">w3id.alpha.sso.ibm.com</span></span></span></span></span></span></p> </td> 
       <td style="width:144.75pt; border-top:none; border-left:none; border-bottom:ridge windowtext 2.25pt; border-right:ridge windowtext 2.25pt"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">July 23rd</span></span></span></span></span></span></p> </td> 
      </tr> 
      <tr> 
       <td style="width:153.0pt; border:ridge windowtext 2.25pt; border-top:none; background:#00a1e0"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><b><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:white">Production</span></span></span></b></span></span></span></p> </td> 
       <td style="width:179.25pt; border-top:none; border-left:none; border-bottom:ridge windowtext 2.25pt; border-right:ridge windowtext 2.25pt; background:#00a1e0"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><b><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:white">w3id.sso.ibm.com</span></span></span></b></span></span></span></p> </td> 
       <td style="width:144.75pt; border-top:none; border-left:none; border-bottom:ridge windowtext 2.25pt; border-right:ridge windowtext 2.25pt; background:#00a1e0"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><b><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:white">August 11th</span></span></span></b></span></span></span></p> </td> 
      </tr> 
     </tbody> 
    </table>
    
     
    
    **What do I need to do?**
    
    **To avoid disruption in service**, applications must ensure that TLS v1.2 is enabled. Failure to take action will lead to an application outage on or after the deployment date.
    
      
    **How to list your applications**
    
    Follow [these steps][]
    
    ([https://w3-connections.ibm.com/wikis/home?lang=en-us\#!/wiki/W89b23bf7ad80\_4411\_822f\_2a6dc171c6b3/page/How%20to%20list%20your%20applications%20and%20remove%20as%20needed][these steps]) to list your applications.
    
    **Support**
    
    ⦁    If you have questions, please post to the [Enterprise and Technology Security Vulnerability Management Community. ][Enterprise and Technology Security Vulnerability Management Community.]  
    ⦁    Please do not post detection and remediation questions to the w3id SSO forum.
 *  Unused Ethernet ports in IBM Office space will be deactivated
    
    Unused Office space Ethernet ports will be deactivated.  If an active device has not been connected to it in the past 75 days, then it will be deactivated.  This mainly affects ports in office, agile areas and conference rooms.  This will not affect ports in private labs.  CIO managed devices can connect to IBM WiFi where connectivity is needed and Ethernet ports are not available or active.  If someone needs to reactivate the Ethernet LAN Port for a CIO managed device, please follow the instructions provided in the section "Reactivate a LAN Port" given in the following URL -**[https://w3.ibm.com/help/\#/article/25139][https_w3.ibm.com_help_article_25139]**
 *  Windows 10 VPN certificates will now automatically be delivered
    
    During the initial Windows 10 setup you will no longer need to "Get VPN Cert" as the VPN certificate will automatically be delivered to your PC.  
    For more information refer to either Help@IBM  [Set Up a PC][] or in the [Windows 10 install Guide][].
 *  WECM (IBM Mobility Client) service decommission alert
    
    Audience: IBM employees using IBM Mobility Client (WECM VPN) for remote access to IBM network.
    
    What's happening? - WECM/IMC software has reached end of life and the extended support agreement will end mid-year. The service will be discontinued by August 31st, 2019. Windows 7 systems within IBM are being migrated to either Windows 10, macOS or Linux, and SAS VPN (based on Cisco AnyConnect) provides remote access for those operating systems. If you are migrated to a new Windows 10, macOS or Linux machine prior to August 1st, SAS VPN will be available to you at installation time.
    
    If you're connecting today with IBM Mobility Client, and will remain on Windows 7 after August 1st, you must migrate to Cisco AnyConnect for Windows 7 using these instructions: [https://w3.ibm.com/help/\#/article/connect\_from\_remote\_location/connect\_from\_remote\_location\_overview ][https_w3.ibm.com_help_article_connect_from_remote_location_connect_from_remote_location_overview]
 *  Microsoft Teams app auto start feature removed by IBM policy
    
    The **"auto start with Windows"** functionality of unsupported app Microsoft Teams has been disabled by IBM policy effective 8/6/19. This does not impact app usability or function.

Outage:

Outage:Print@IBM Americas will be down during scheduled weekend maintenance window for 2 hrsView

 Details  

 Close 

<table>
 <tbody>
  <tr>
   <th>Outage Name</th>
   <th>Type</th>
   <th>Start Time</th>
   <th>Estimated Fix</th>
  </tr> 
  <tr>
   <td><a rel="nofollow">Print@IBM Americas will be down during scheduled weekend maintenance window for 2 hrs</a></td>
   <td>Planned</td>
   <td><span>10 Aug 2019</span>11:00 PM </td>
   <td>11 Aug 2019 1:00 AM EDT</td>
  </tr> 
 </tbody>
</table>

Only outages for the most common systems in your location are displayed here. View All outages for a complete list of worldwide outages.

6 Help Advisor Alerts.w3id Single Sign-on (SSO), W3 Enterprise Search, Ethernet & LAN, Windows 10, Secure Access Services (SAS). Close   Details 

 Details 

 Close 

 *  Information for Web Applications that receive "Secure Connection Failed" after August 11th
    
    If a user accessing web applications (including the w3id Profile for Password Management application at [https://w3.ibm.com/password][https_w3.ibm.com_password] or [https://w3idprofile.sso.ibm.com/password][https_w3idprofile.sso.ibm.com_password]) receives a "Secure Connection Failed" message after the August 11th w3id SSO change to disable older Transport Layer Security (TLS) versions 1.0 and 1.1, it may mean that an older browser is being used.
    
     
    
    **Action: ** users may need to update to the latest browser version which supports TLS v1.2.
    
     
    
    More information and details are posted here:  [https://w3-connections.ibm.com/wikis/home?lang=en-us\#!/wiki/W89b23bf7ad80\_4411\_822f\_2a6dc171c6b3/page/TLS%201.0%20and%201.1%20Browser%20Errors][https_w3-connections.ibm.com_wikis_home_lang_en-us_wiki_W89b23bf7ad80_4411_822f_2a6dc171c6b3_page_TLS_201.0_20and_201.1_20Browser_20Errors]
 *  w3id Single Sign On (SSO) to Disable Transport Layer Security (TLS) v1 and v1.1 in production on August 11th.
    
    **Subject**:  w3id Single Sign On (SSO) to Disable Transport Layer Security (TLS) v1 and v1.1 in production on **August 11th**.  
      
    This announcement has been sent to all OpenID Connect (OIDC) and Security Assertion Markup Language (SAML) adopters since July 12th (reminders are being sent).
    
     
    
    **Why?**
    
    In May, the Mixed Address Database (MAD) Scanner was updated to identify infrastructure with TLS v1.0 and v1.1 enabled as low severity vulnerabilities. Section 6.7.3 of the IT Security Standard (ITSS) requires low vulnerabilities to be address within 90 days for internal assets and 30 days for internet facing assets.  As [announced in the w3id SSO forum][] [https://w3-connections.ibm.com/forums/html/topic?id=312d26dd-a203-4578-941c-680431f1c55b&ps=100][announced in the w3id SSO forum]these protocols will be disabled in Production on **August 11th**. The testing and staging environments will be also affected.  The schedule is provided below.  
      
    **Impacted applications**
    
    Applications using the OpenID Connect protocol, that call the /introspect or /token endpoints and do not have TLS v1.2  enabled.  
     
    
    **Applications that are not impacted**
    
    ⦁    Applications using the SAML protocol and implicit OpenID Connect will not be impacted as all connections originate from the end user's browser.
    
    ⦁    Third party applications using SAML 2 will not be impacted by this change.  (i.e. Box, Office 365, Workday, WebEx, Slack, etc.) .  
      
    **When?**
    
    The change will be deployed in **Production** on **August 11th**.
    
     
    
    <table style="border-collapse:collapse; border:ridge windowtext 2.25pt"> 
     <tbody> 
      <tr> 
       <td style="width:153.0pt; border:ridge windowtext 2.25pt"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><b><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">w3id Environment</span></span></span></b></span></span></span></p> </td> 
       <td style="width:179.25pt; border:ridge windowtext 2.25pt; border-left:none"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><b><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">Hostname</span></span></span></b></span></span></span></p> </td> 
       <td style="width:144.75pt; border:ridge windowtext 2.25pt; border-left:none"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><b><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">Deployment Date</span></span></span></b></span></span></span></p> </td> 
      </tr> 
      <tr> 
       <td style="width:153.0pt; border:ridge windowtext 2.25pt; border-top:none"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">Test</span></span></span></span></span></span></p> </td> 
       <td style="width:179.25pt; border-top:none; border-left:none; border-bottom:ridge windowtext 2.25pt; border-right:ridge windowtext 2.25pt"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">w3id-test.sso.ibm.com</span></span></span></span></span></span></p> </td> 
       <td style="width:144.75pt; border-top:none; border-left:none; border-bottom:ridge windowtext 2.25pt; border-right:ridge windowtext 2.25pt"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">July 16th</span></span></span></span></span></span></p> </td> 
      </tr> 
      <tr> 
       <td style="width:153.0pt; border:ridge windowtext 2.25pt; border-top:none"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">Staging</span></span></span></span></span></span></p> </td> 
       <td style="width:179.25pt; border-top:none; border-left:none; border-bottom:ridge windowtext 2.25pt; border-right:ridge windowtext 2.25pt"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">w3id.alpha.sso.ibm.com</span></span></span></span></span></span></p> </td> 
       <td style="width:144.75pt; border-top:none; border-left:none; border-bottom:ridge windowtext 2.25pt; border-right:ridge windowtext 2.25pt"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">July 23rd</span></span></span></span></span></span></p> </td> 
      </tr> 
      <tr> 
       <td style="width:153.0pt; border:ridge windowtext 2.25pt; border-top:none; background:#00a1e0"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><b><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:white">Production</span></span></span></b></span></span></span></p> </td> 
       <td style="width:179.25pt; border-top:none; border-left:none; border-bottom:ridge windowtext 2.25pt; border-right:ridge windowtext 2.25pt; background:#00a1e0"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><b><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:white">w3id.sso.ibm.com</span></span></span></b></span></span></span></p> </td> 
       <td style="width:144.75pt; border-top:none; border-left:none; border-bottom:ridge windowtext 2.25pt; border-right:ridge windowtext 2.25pt; background:#00a1e0"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><b><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:white">August 11th</span></span></span></b></span></span></span></p> </td> 
      </tr> 
     </tbody> 
    </table>
    
     
    
    **What do I need to do?**
    
    **To avoid disruption in service**, applications must ensure that TLS v1.2 is enabled. Failure to take action will lead to an application outage on or after the deployment date.
    
      
    **How to list your applications**
    
    Follow [these steps][]
    
    ([https://w3-connections.ibm.com/wikis/home?lang=en-us\#!/wiki/W89b23bf7ad80\_4411\_822f\_2a6dc171c6b3/page/How%20to%20list%20your%20applications%20and%20remove%20as%20needed][these steps]) to list your applications.
    
    **Support**
    
    ⦁    If you have questions, please post to the [Enterprise and Technology Security Vulnerability Management Community. ][Enterprise and Technology Security Vulnerability Management Community.]  
    ⦁    Please do not post detection and remediation questions to the w3id SSO forum.
 *  Unused Ethernet ports in IBM Office space will be deactivated
    
    Unused Office space Ethernet ports will be deactivated.  If an active device has not been connected to it in the past 75 days, then it will be deactivated.  This mainly affects ports in office, agile areas and conference rooms.  This will not affect ports in private labs.  CIO managed devices can connect to IBM WiFi where connectivity is needed and Ethernet ports are not available or active.  If someone needs to reactivate the Ethernet LAN Port for a CIO managed device, please follow the instructions provided in the section "Reactivate a LAN Port" given in the following URL -**[https://w3.ibm.com/help/\#/article/25139][https_w3.ibm.com_help_article_25139]**
 *  Windows 10 VPN certificates will now automatically be delivered
    
    During the initial Windows 10 setup you will no longer need to "Get VPN Cert" as the VPN certificate will automatically be delivered to your PC.  
    For more information refer to either Help@IBM  [Set Up a PC][] or in the [Windows 10 install Guide][].
 *  WECM (IBM Mobility Client) service decommission alert
    
    Audience: IBM employees using IBM Mobility Client (WECM VPN) for remote access to IBM network.
    
    What's happening? - WECM/IMC software has reached end of life and the extended support agreement will end mid-year. The service will be discontinued by August 31st, 2019. Windows 7 systems within IBM are being migrated to either Windows 10, macOS or Linux, and SAS VPN (based on Cisco AnyConnect) provides remote access for those operating systems. If you are migrated to a new Windows 10, macOS or Linux machine prior to August 1st, SAS VPN will be available to you at installation time.
    
    If you're connecting today with IBM Mobility Client, and will remain on Windows 7 after August 1st, you must migrate to Cisco AnyConnect for Windows 7 using these instructions: [https://w3.ibm.com/help/\#/article/connect\_from\_remote\_location/connect\_from\_remote\_location\_overview ][https_w3.ibm.com_help_article_connect_from_remote_location_connect_from_remote_location_overview]
 *  Microsoft Teams app auto start feature removed by IBM policy
    
    The **"auto start with Windows"** functionality of unsupported app Microsoft Teams has been disabled by IBM policy effective 8/6/19. This does not impact app usability or function.

 *  Information for Web Applications that receive "Secure Connection Failed" after August 11th
    
    If a user accessing web applications (including the w3id Profile for Password Management application at [https://w3.ibm.com/password][https_w3.ibm.com_password] or [https://w3idprofile.sso.ibm.com/password][https_w3idprofile.sso.ibm.com_password]) receives a "Secure Connection Failed" message after the August 11th w3id SSO change to disable older Transport Layer Security (TLS) versions 1.0 and 1.1, it may mean that an older browser is being used.
    
     
    
    **Action: ** users may need to update to the latest browser version which supports TLS v1.2.
    
     
    
    More information and details are posted here:  [https://w3-connections.ibm.com/wikis/home?lang=en-us\#!/wiki/W89b23bf7ad80\_4411\_822f\_2a6dc171c6b3/page/TLS%201.0%20and%201.1%20Browser%20Errors][https_w3-connections.ibm.com_wikis_home_lang_en-us_wiki_W89b23bf7ad80_4411_822f_2a6dc171c6b3_page_TLS_201.0_20and_201.1_20Browser_20Errors]
 *  w3id Single Sign On (SSO) to Disable Transport Layer Security (TLS) v1 and v1.1 in production on August 11th.
    
    **Subject**:  w3id Single Sign On (SSO) to Disable Transport Layer Security (TLS) v1 and v1.1 in production on **August 11th**.  
      
    This announcement has been sent to all OpenID Connect (OIDC) and Security Assertion Markup Language (SAML) adopters since July 12th (reminders are being sent).
    
     
    
    **Why?**
    
    In May, the Mixed Address Database (MAD) Scanner was updated to identify infrastructure with TLS v1.0 and v1.1 enabled as low severity vulnerabilities. Section 6.7.3 of the IT Security Standard (ITSS) requires low vulnerabilities to be address within 90 days for internal assets and 30 days for internet facing assets.  As [announced in the w3id SSO forum][] [https://w3-connections.ibm.com/forums/html/topic?id=312d26dd-a203-4578-941c-680431f1c55b&ps=100][announced in the w3id SSO forum]these protocols will be disabled in Production on **August 11th**. The testing and staging environments will be also affected.  The schedule is provided below.  
      
    **Impacted applications**
    
    Applications using the OpenID Connect protocol, that call the /introspect or /token endpoints and do not have TLS v1.2  enabled.  
     
    
    **Applications that are not impacted**
    
    ⦁    Applications using the SAML protocol and implicit OpenID Connect will not be impacted as all connections originate from the end user's browser.
    
    ⦁    Third party applications using SAML 2 will not be impacted by this change.  (i.e. Box, Office 365, Workday, WebEx, Slack, etc.) .  
      
    **When?**
    
    The change will be deployed in **Production** on **August 11th**.
    
     
    
    <table style="border-collapse:collapse; border:ridge windowtext 2.25pt"> 
     <tbody> 
      <tr> 
       <td style="width:153.0pt; border:ridge windowtext 2.25pt"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><b><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">w3id Environment</span></span></span></b></span></span></span></p> </td> 
       <td style="width:179.25pt; border:ridge windowtext 2.25pt; border-left:none"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><b><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">Hostname</span></span></span></b></span></span></span></p> </td> 
       <td style="width:144.75pt; border:ridge windowtext 2.25pt; border-left:none"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><b><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">Deployment Date</span></span></span></b></span></span></span></p> </td> 
      </tr> 
      <tr> 
       <td style="width:153.0pt; border:ridge windowtext 2.25pt; border-top:none"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">Test</span></span></span></span></span></span></p> </td> 
       <td style="width:179.25pt; border-top:none; border-left:none; border-bottom:ridge windowtext 2.25pt; border-right:ridge windowtext 2.25pt"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">w3id-test.sso.ibm.com</span></span></span></span></span></span></p> </td> 
       <td style="width:144.75pt; border-top:none; border-left:none; border-bottom:ridge windowtext 2.25pt; border-right:ridge windowtext 2.25pt"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">July 16th</span></span></span></span></span></span></p> </td> 
      </tr> 
      <tr> 
       <td style="width:153.0pt; border:ridge windowtext 2.25pt; border-top:none"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">Staging</span></span></span></span></span></span></p> </td> 
       <td style="width:179.25pt; border-top:none; border-left:none; border-bottom:ridge windowtext 2.25pt; border-right:ridge windowtext 2.25pt"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">w3id.alpha.sso.ibm.com</span></span></span></span></span></span></p> </td> 
       <td style="width:144.75pt; border-top:none; border-left:none; border-bottom:ridge windowtext 2.25pt; border-right:ridge windowtext 2.25pt"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:black">July 23rd</span></span></span></span></span></span></p> </td> 
      </tr> 
      <tr> 
       <td style="width:153.0pt; border:ridge windowtext 2.25pt; border-top:none; background:#00a1e0"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><b><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:white">Production</span></span></span></b></span></span></span></p> </td> 
       <td style="width:179.25pt; border-top:none; border-left:none; border-bottom:ridge windowtext 2.25pt; border-right:ridge windowtext 2.25pt; background:#00a1e0"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><b><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:white">w3id.sso.ibm.com</span></span></span></b></span></span></span></p> </td> 
       <td style="width:144.75pt; border-top:none; border-left:none; border-bottom:ridge windowtext 2.25pt; border-right:ridge windowtext 2.25pt; background:#00a1e0"> <p style="margin-top:0cm; margin-right:0cm; margin-bottom:.0001pt; margin-left:1.5pt; text-align:center; padding:.75pt .75pt .75pt .75pt"><span style="line-height:normal"><span style="page-break-after:avoid"><span style="text-autospace:none"><b><span style="font-size:10.0pt"><span style="font-family:&quot;IBM Plex Sans&quot;,sans-serif"><span style="color:white">August 11th</span></span></span></b></span></span></span></p> </td> 
      </tr> 
     </tbody> 
    </table>
    
     
    
    **What do I need to do?**
    
    **To avoid disruption in service**, applications must ensure that TLS v1.2 is enabled. Failure to take action will lead to an application outage on or after the deployment date.
    
      
    **How to list your applications**
    
    Follow [these steps][]
    
    ([https://w3-connections.ibm.com/wikis/home?lang=en-us\#!/wiki/W89b23bf7ad80\_4411\_822f\_2a6dc171c6b3/page/How%20to%20list%20your%20applications%20and%20remove%20as%20needed][these steps]) to list your applications.
    
    **Support**
    
    ⦁    If you have questions, please post to the [Enterprise and Technology Security Vulnerability Management Community. ][Enterprise and Technology Security Vulnerability Management Community.]  
    ⦁    Please do not post detection and remediation questions to the w3id SSO forum.
 *  Unused Ethernet ports in IBM Office space will be deactivated
    
    Unused Office space Ethernet ports will be deactivated.  If an active device has not been connected to it in the past 75 days, then it will be deactivated.  This mainly affects ports in office, agile areas and conference rooms.  This will not affect ports in private labs.  CIO managed devices can connect to IBM WiFi where connectivity is needed and Ethernet ports are not available or active.  If someone needs to reactivate the Ethernet LAN Port for a CIO managed device, please follow the instructions provided in the section "Reactivate a LAN Port" given in the following URL -**[https://w3.ibm.com/help/\#/article/25139][https_w3.ibm.com_help_article_25139]**
 *  Windows 10 VPN certificates will now automatically be delivered
    
    During the initial Windows 10 setup you will no longer need to "Get VPN Cert" as the VPN certificate will automatically be delivered to your PC.  
    For more information refer to either Help@IBM  [Set Up a PC][] or in the [Windows 10 install Guide][].
 *  WECM (IBM Mobility Client) service decommission alert
    
    Audience: IBM employees using IBM Mobility Client (WECM VPN) for remote access to IBM network.
    
    What's happening? - WECM/IMC software has reached end of life and the extended support agreement will end mid-year. The service will be discontinued by August 31st, 2019. Windows 7 systems within IBM are being migrated to either Windows 10, macOS or Linux, and SAS VPN (based on Cisco AnyConnect) provides remote access for those operating systems. If you are migrated to a new Windows 10, macOS or Linux machine prior to August 1st, SAS VPN will be available to you at installation time.
    
    If you're connecting today with IBM Mobility Client, and will remain on Windows 7 after August 1st, you must migrate to Cisco AnyConnect for Windows 7 using these instructions: [https://w3.ibm.com/help/\#/article/connect\_from\_remote\_location/connect\_from\_remote\_location\_overview ][https_w3.ibm.com_help_article_connect_from_remote_location_connect_from_remote_location_overview]
 *  Microsoft Teams app auto start feature removed by IBM policy
    
    The **"auto start with Windows"** functionality of unsupported app Microsoft Teams has been disabled by IBM policy effective 8/6/19. This does not impact app usability or function.

# What do you need help with? #

Search input  Search  Clear

Cancel

Top results

Press Enter to see all  search results

 *     
    What's new 
 *  Setup Created with Sketch.
    
      
    Device setup 
 *    
    Site Tour 

![mojave_hero.png][]

  Article 1/ 10

## Required Update to Mojave 10.14.5 ##

macOS Mojave 10.14.5 is now the minimum compliant operating system for Mac users. If your Mac isn't running 10.14.5, Mac@IBM will push a notification advising you of required actions depending on if you're running High Sierra or an earlier version of Mojave.

Learn more View all featured

## Featured Products ##

Find support articles for these frequently searched products.

 *  ![IBM Notes][]
    
    IBM Notes
 *  ![Windows 10][]
    
    Windows 10
 *  ![Windows 7][]
    
    Windows 7
 *  View more

View more

 *   
    
    1
    
    ## Outages ##
 *  ## Tickets ##
 *  ## What's new ##
 *  ## Top Issues ##
 *  ## Products ##
 *  Popular Support
 *  Try these support topics frequently viewed by other IBMers.
 *  ### Set Up at IBM ###
    
    An introduction of IT tools and services at IBM.
    
    ### Upgrade to macOS Mojave (10.14.5) ###
    
    Upgrade your Mac to the IBM approved version of macOS Mojave.
    
    ### Connect to the IBM Wireless Network ###
    
    Connect your computer or mobile device to the IBM wireless network.
    
    ### Install Microsoft Office ###
    
    Install Microsoft Office on your computer or mobile device.
    
    ### Renew a Certificate for the IBM Wi-Fi Network ###
    
    Renew and configure the certificate you use to connect to IBM from within an IBM site.
    
    ### Get Started with Cisco Webex Meetings ###
    
    Create your Webex profile, attend a Webex meeting, and determine the type of meeting you need.Tips for improving audio quality and security and privacy information.
 *  View all...

## Need more help for **Mac**? ##

Contact Support

Get support by phone, chat, web ticket or forum.

Support options available for

Search

 Search

 Search

No matches found

Start typing to see the potential matches...

Recent topics

Oops, there was a problem. Try again later.

 Don’t see the options that you’re looking for?

 

**General support on another topic**

Open the support slide out

## About Help@IBM ##

Please visit the [Help@IBM Community][Help_IBM Community] for:

 *  [Latest Help@IBM news][Latest Help_IBM news]
 *  [Share your experience with other IBMers][]
 *  [Submit and vote on ideas][]

# Content Removed #

##  ##

The topic was removed or is no longer available

OK

# Content Removed #

##  ##

The topic was removed or is no longer available

OK


[Go to W3 site _external link]: https://w3.ibm.com/
[Image 1]: 
[My Devices]: https://w3.ibm.com/help/mobile/helpentry.html?redirect_uri=https%3A%2F%2Fw3.ibm.com%2Fhelp%2F%23%2Fmac%2Fus_imt
[https_w3.ibm.com_password]: https://w3id.ibm.com/password
[https_w3idprofile.sso.ibm.com_password]: https://w3idprofile.sso.ibm.com/password
[https_w3-connections.ibm.com_wikis_home_lang_en-us_wiki_W89b23bf7ad80_4411_822f_2a6dc171c6b3_page_TLS_201.0_20and_201.1_20Browser_20Errors]: https://w3-connections.ibm.com/wikis/home?lang=en-us#!/wiki/W89b23bf7ad80_4411_822f_2a6dc171c6b3/page/TLS%201.0%20and%201.1%20Browser%20Errors
[announced in the w3id SSO forum]: https://w3-connections.ibm.com/forums/html/topic?id=312d26dd-a203-4578-941c-680431f1c55b&ps=100
[these steps]: https://w3-connections.ibm.com/wikis/home?lang=en-us#!/wiki/W89b23bf7ad80_4411_822f_2a6dc171c6b3/page/How%20to%20list%20your%20applications%20and%20remove%20as%20needed
[Enterprise and Technology Security Vulnerability Management Community.]: https://w3-connections.ibm.com/communities/service/html/communitystart?communityUuid=b6dcccee-5a45-4088-8ba9-652558a570a2
[https_w3.ibm.com_help_article_25139]: https://w3.ibm.com/help/#/article/25139
[Set Up a PC]: https://w3.ibm.com/help/#/article/win10_new_pc/overview?requestedTopicId=overview
[Windows 10 install Guide]: https://setupmypc.ibm.com/win10install
[https_w3.ibm.com_help_article_connect_from_remote_location_connect_from_remote_location_overview]: https://w3.ibm.com/help/#/article/connect_from_remote_location/connect_from_remote_location_overview
[mojave_hero.png]: https://prd1pcrdw3mac.w3-969.ibm.com/help/static/mojave_hero/en/mojave_hero.png
[IBM Notes]: https://prdpcrdw3mac.w3-969.ibm.com:443/help/static/icons/products/notes_client.svg
[Windows 10]: https://prdpcrdw3mac.w3-969.ibm.com:443/help/static/icons/products/os_win10.svg
[Windows 7]: https://prdpcrdw3mac.w3-969.ibm.com:443/help/static/icons/products/os_win7.svg
[Help_IBM Community]: https://apps.na.collabserv.com/communities/service/html/communitystart?communityUuid=e08d5a18-1566-4dab-af67-528cd935d3fc
[Latest Help_IBM news]: https://apps.na.collabserv.com/wikis/home?lang=en-us#!/wiki/W602679af2a9e_437a_b02e_4719fba6fa3c/page/News
[Share your experience with other IBMers]: https://apps.na.collabserv.com/communities/service/html/communityoverview?communityUuid=e08d5a18-1566-4dab-af67-528cd935d3fc#fullpageWidgetId=Wf02ce5d9291a_44fc_b105_113901f4e3f1
[Submit and vote on ideas]: https://apps.na.collabserv.com/communities/service/html/communityoverview?communityUuid=e08d5a18-1566-4dab-af67-528cd935d3fc#fullpageWidgetId=W12ca17405a67_4449_8bcd_071b93c1509c